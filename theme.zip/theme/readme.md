# NazAdv Website

## How To Run ?

1. Create a New Wordpress Installation
2. Create a New Theme Folder (NAZ) inside the wp-content/themes folder.
3. Git clone the repository
4. Activate The Wordpress Theme
5. Run The Following Commands

```
npm install 
npx mix watch 
```